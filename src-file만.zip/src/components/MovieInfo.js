

function MovieInfo() {
    return (
        <div>
            <hr />
            <h2> 영화 정보</h2>
            <table border='1'>
                <tr><th>제목</th><th>감독</th><th>배우</th>
                    <th>개봉일</th><th>장르</th></tr>
                <tr><td>스파이더맨 노 웨이 홈</td>
                    <td>존 왓츠</td><td>톰 홀랜드</td>
                    <td>2021-12-15</td><td>액션</td></tr>
                <tr><td>킹스맨 : 퍼스트 에이전트</td>
                    <td>매튜 본</td><td>팔프 파인즈</td>
                    <td>2021-12-22</td><td>액션</td></tr>


            </table>
        </div>
    )
}

export default MovieInfo