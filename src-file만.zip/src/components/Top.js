import React, { useState } from 'react';
import { Link, Routes, Route } from 'react-router-dom';
const Top = () => {
    let [menuViewState, setMenuViewState] = useState("MenuHidden");

    const menuHiddenChange = () => {
        if (menuViewState === "MenuHidden") {
            setMenuViewState("MenuView");
        } else {
            setMenuViewState("MenuHidden");
        }
    }
    return (
        <div className='leftFlexDiv'>

            <div>
                <h3><Link to="/" className='menuHome'>AOC</Link></h3>
                <button className='menuBtn' onClick={menuHiddenChange}>Menu</button>
            </div>
            <div className={menuViewState}>
                <ul className='menuNavbar'>
                    <li><Link to="/">홈화면으로 이동</Link></li>
                    <li><Link to="/about">About으로 이동</Link></li>
                    <li><a href="https://www.naver.com">네이버</a></li>
                    <li><Link to="/movieinfo">MovieInfo 이동</Link></li>
                    <li><Link to="/movie/spider">킹스맨 이동</Link></li>
                </ul>
            </div>

        </div>
    );
};

export default Top;