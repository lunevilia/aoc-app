import React from 'react';

const About = () => {
    return (
        <div className='about'>
            <h2>About 화면</h2>
        </div>
    );
};

export default About;