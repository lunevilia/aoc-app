import React from 'react';
import { Link, Routes, Route } from 'react-router-dom';
const Home = () => {
    return (
        <div className='home'>
            <h2>홈화면</h2>

            <div><Link to="/">홈화면으로 이동</Link></div>
            <div><Link to="/about">About으로 이동</Link></div>
            <div><a href="https://www.naver.com">네이버</a></div>
            <div><Link to="/movieinfo">MovieInfo 이동</Link></div>
            <div><Link to="/movie/spider">킹스맨 이동</Link></div>

        </div>
    );
};

export default Home;