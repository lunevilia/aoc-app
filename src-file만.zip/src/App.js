import logo from './logo.svg';
import { Link, Routes, Route } from 'react-router-dom';
import Top from './components/Top';
import About from './components/About';
import Home from './components/Home';
import Movie from './components/Movie';
import MovieInfo from './components/MovieInfo';
import './App.css';
import { useState } from 'react';

function App() {

  return (
    <div className="App">
      <Top />

      <div className='rightSideDiv'>


        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/movieinfo" element={<MovieInfo />} />
          <Route path="/movie/:keyword" element={<Movie />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
