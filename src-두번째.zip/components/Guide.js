import React from 'react';

const Guide = () => {
    return (
        <div className='guide'>
            <h2>코로나 코로나 방역지침</h2>
        </div>
    );
};

export default Guide;