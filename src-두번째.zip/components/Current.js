import React from 'react';

const Current = () => {
    return (
        <div className='current'>
            <h2>현황</h2>
        </div>
    );
};

export default Current;