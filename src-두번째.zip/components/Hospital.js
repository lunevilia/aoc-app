import React from 'react';

const Hospital = () => {
    return (
        <div className='hospital'>
            <h3>인근 병원</h3>
        </div>
    );
};

export default Hospital;