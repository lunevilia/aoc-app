import React from 'react';

const Symptom = () => {
    return (
        <div className='symptom'>
            <h2>코로나 증상</h2>
        </div>
    );
};

export default Symptom;