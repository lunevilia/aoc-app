import React from 'react';

const MaskGuide = () => {
    return (
        <div className='maskGuide'>

        </div>
    );
};

export default MaskGuide;