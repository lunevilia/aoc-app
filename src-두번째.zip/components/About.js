import React from 'react';

const About = () => {
    return (
        <div className='about'>
            <h2>사이트 관련 문의</h2>
        </div>
    );
};

export default About;