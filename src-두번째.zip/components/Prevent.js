import React from 'react';

const Prevent = () => {
    return (
        <div className='prevent'>
            <h2>코로나 예방방법</h2>
        </div>
    );
};

export default Prevent;