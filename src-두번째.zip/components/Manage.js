import React from 'react';

const Manage = () => {
    return (
        <div className='manage'>
            <h2>확진 후 관리</h2>
        </div>
    );
};

export default Manage;