import React from 'react';

const Vaccine = () => {
    return (
        <div className='vaccine'>
            <h2>코로나 증상</h2>
        </div>
    );
};

export default Vaccine;