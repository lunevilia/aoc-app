import React from 'react';

const Isolation = () => {
    return (
        <div className='isolation'>
            <h2>격리 후 조치</h2>
        </div>
    );
};

export default Isolation;