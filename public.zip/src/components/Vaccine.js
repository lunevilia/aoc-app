import React from 'react';
import './Vaccine/Vaccine.css';
import { Routes, Route } from 'react-router-dom';
import VaccineInfo from './Vaccine/VaccineInfo';
import ChildVaccine from './Vaccine/ChildVaccine';
import { useDispatch } from 'react-redux';
function Vaccine() {
    const dispatch = useDispatch();
    dispatch({ type: 'CrtMapState', payload: "noViewCrtMap" });
    dispatch({ type: 'PAGEImg', payload: "/img/VaccineMain.jpg" });
    dispatch({ type: 'PAGE', payload: "코로나 백신" });
    return (
        <div className='vaccine'>
            <h2>코로나 백신</h2>
            <div className='container'>


                <div>
                    <Routes>
                        <Route path='/' element={<VaccineInfo />} />
                        <Route path='/vaccineInfo/:keyword' element={<VaccineInfo />} />
                        <Route path='/ChildVaccine' element={<ChildVaccine />} />
                    </Routes>
                </div>

            </div>
            <h2>Related Posts</h2>
        </div>
    );
};

export default Vaccine;